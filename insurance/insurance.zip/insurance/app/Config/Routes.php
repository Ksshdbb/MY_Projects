<?php

use CodeIgniter\Router\RouteCollection;

$routes->get('/', 'Auth::index');
$routes->get('auth/logout', 'Auth::logout');

$routes->post('auth/check', 'Auth::check');


$routes->group('',['filter'=>'auth'],function($routes){
    $routes->get('/auth/dashboard', 'Auth::dashboard');
    $routes->get('/auth/dashboard2', 'Auth::dashboard2');
    $routes->post('/auth/addMember/(:num)', 'Auth::add_member/$1');
    $routes->get('/auth/edit/(:num)', 'Auth::edit/$1');
    $routes->get('/auth/editer/(:num)/(:any)', 'Auth::editer/$1/$2');
    $routes->get('/auth/ed/(:num)/(:any)', 'Auth::ed/$1/$2');
   # $routes->get('/auth/form/(:num)/(:any)', 'Auth::ed/$1/$2');
    $routes->get('/auth/adder/(:num)', 'Auth::adder/$1');
    $routes->post('/auth/save/(:any)', 'Auth::save/$1');
    $routes->get('/auth/edit2/(:num)/(:any)', 'Auth::edit2/$1/$2');
    $routes->post('auth/validateRulesAjax', 'Auth::validateRulesAjax');


});
