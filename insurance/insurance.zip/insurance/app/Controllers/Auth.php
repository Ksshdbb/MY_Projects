<?php

namespace App\Controllers;

use App\Models\FamilyModel;
use App\Models\UserModel;

class Auth extends BaseController
{
    public function index()
    {
        if (session()->has("loggedUser")) {
            return redirect()->to(base_url("auth/dashboard"));
        }
        return view("auth/login");
    }

    public function dashboard2()
    {
        return view('/auth/dashboard2');
    }

    public function check()
    {
        $validation = $this->validate([
            'username' => [
                'rules' => 'required|is_not_unique[users.username]',
                'errors' => [
                    'required' => 'Username Cannot be Empty',
                    'is_not_unique' => 'Invalid Username'
                ]
            ],
            'password' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Password cannot be empty'
                ]
            ]
        ]);

        if (!$validation) {
            return view('/auth/login', ['validation' => $this->validator]);
        } else {
            $userModel = new UserModel();
            $username = $this->request->getPost("username");
            $password = $this->request->getPost("password");
            $user_info = $userModel->where('username', $username)->first();

            if ($password == $user_info["password"]) {
                session()->set('loggedUser', $user_info['username']);
                return redirect()->to(base_url('auth/dashboard'));
            } else {
                session()->setFlashdata('fail', 'Wrong Password');
                return redirect()->to(base_url('/'));
            }
        }
    }

    public function dashboard()
    {
        $model = new FamilyModel();
        $records['familyhead'] = $model->where('relationship', 'self')->orderBy('familyCode','ASC')->findAll();
        return view('auth/dashboard', ['records' => $records]);
    }

    public function logout()
    {
        if (session()->has("loggedUser")) {
            session()->remove("loggedUser");
            session()->setFlashdata('fail', 'User Logged out');
            return redirect()->to(base_url('/'));
        }
    }

    public function edit($familyCode) {
        $model = new FamilyModel();
    
        $record['allMembers'] = $model->where('familyCode', $familyCode)
                                       ->orderBy('relationship = \'self\' DESC')
                                       ->findAll();
        
        $selfMember = $model->where('familyCode', $familyCode)
                            ->where('relationship', 'self')
                            ->first();
        $record['selfName'] = $selfMember ? $selfMember['name'] : '';
        $record['familyCode'] = $familyCode; // Add this line
    
        return view('auth/edit', $record);
    }

    public function edit2($familyCode,$name) {
        $model = new FamilyModel();
        
        // Retrieve specific member data based on name or other identifiers
        $member = $model->where('familyCode', $familyCode)
                        ->where('relationship', 'self') // or any specific relationship
                        ->first();
        
        // Check if the member is found
        if ($member) {
            return view('auth/ed', ['member' => $member]);
        } else {
            // Handle case when member is not found
            session()->setFlashdata('error', 'Member not found.');
            return redirect()->to(base_url('/auth/dashboard/edit'));
        }
    }
    
    
    public function editer($familyCode,$name) {    
        $model = new FamilyModel();
    
        $deletedRows = $model->where('familyCode', $familyCode)->where('name', $name)->delete();
        
    
        if ($deletedRows) {
        //     echo $familyCode;
        // die();
            return redirect()->to(base_url('/auth/edit/' . $familyCode))->with('success', 'Family member deleted successfully.');
        } else {
            return redirect()->to(base_url('/auth/edit/' . $familyCode))->with('error', 'Family member not found or deletion failed.');
        }
    }

    public function ed($familyCode, $name) {
        $model = new FamilyModel();
    
        $data = [
            'familyCode' => $familyCode,
            'selfName' => $name,
            'allMembers' => $model->where('familyCode', $familyCode)
                                  ->where('name', $name)
                                  ->findAll(),
            'action' => 'edit'
        ];
    
        return view('auth/ed', $data);
    }
    

    public function save($name) {
        $model = new FamilyModel();
    
        $familyCodeArray = $this->request->getPost('familyCode');
        $nameArray = $this->request->getPost('name');
        $genderArray = $this->request->getPost('gender');
        $dobArray = $this->request->getPost('dob');
        $relationshipArray = $this->request->getPost('relationship');
    
        foreach ($familyCodeArray as $index => $familyCode) {
            $data = [
                'name' => $nameArray[$index],
                'gender' => $genderArray[$index],
                'dob' => $dobArray[$index],
                'relationship' => $relationshipArray[$index],
            ];
    
            $model->set($data)
                  ->where('familyCode', $familyCode)
                  ->where('name', $name)
                  ->update();
        }
    
        $lastFamilyCode = end($familyCodeArray);
        session()->setFlashdata('success', 'Family member(s) updated successfully.');

        // echo $lastFamilyCode;
        // die();
    
        return redirect()->to(base_url('auth/edit/' . $lastFamilyCode));
    }

    public function adder($familyCode) {
        $data = [
            'familyCode' => $familyCode,
            'action' => 'add'
        ];
        return view('auth/ed', $data);
    }
    
    
    
    public function add_member($familyCode) {
        $model = new FamilyModel();
        
        
        $relationship = $this->request->getPost('relationship');
        if ($relationship === 'self') {
            session()->setFlashdata('error', 'The relationship cannot be "Self."');
            return redirect()->to(base_url('auth/adder'));
        }
        
        $data = [
            'name' => $this->request->getPost('name'),
            'gender' => $this->request->getPost('gender'),
            'dob' => $this->request->getPost('dob'),
            'relationship' => $relationship,
            'familyCode' => $familyCode,
        ];
        
        $model->insert($data);
        
        session()->setFlashdata('success', 'Family member added successfully.');
        
        return redirect()->to(base_url('auth/edit/' . $familyCode));
    }
    public function validateRulesAjax()
    {
        $familyCode = $this->request->getPost('familyCode');
        $dob = $this->request->getPost('dob');
        $gender = $this->request->getPost('gender');
        $relationship = $this->request->getPost('relationship');
        $field = $this->request->getPost('field');
        
        $db = \Config\Database::connect();
        $query = $db->table('family_rules')->getWhere(['familyCode' => $familyCode])->getRow();

        $errors = [];
        if ($query && $rules = json_decode($query->rules, true)) {
            // Validate DOB against minAge and maxAge
            if ($field == 'dob') {
                $age = date_diff(date_create($dob), date_create('today'))->y;
                if (isset($rules['minAge']) && $age < $rules['minAge']) {
                    $errors[] = ['field' => 'dob', 'message' => 'Minimum age requirement not met.'];
                }
                if (isset($rules['maxAge']) && $age > $rules['maxAge']) {
                    $errors[] = ['field' => 'dob', 'message' => 'Maximum age limit exceeded.'];
                }
            }

            // Validate gender
            if ($field == 'gender' && isset($rules['allowedGenders']) && !in_array($gender, $rules['allowedGenders'])) {
                $errors[] = ['field' => 'gender', 'message' => 'This gender is not allowed.'];
            }

            // Validate relationship member limit
            if ($field == 'relationship' && isset($rules['allowedMembers'][$relationship])) {
                $familyModel = new FamilyModel();
                $existingCount = $familyModel->where(['familyCode' => $familyCode, 'relationship' => $relationship])->countAllResults();
                if ($existingCount >= $rules['allowedMembers'][$relationship]) {
                    $errors[] = ['field' => 'relationship', 'message' => 'This relationship type has reached its limit.'];
                }
            }
        }

        return $this->response->setJSON(['success' => empty($errors), 'errors' => $errors]);
    }
    
}
    
 

