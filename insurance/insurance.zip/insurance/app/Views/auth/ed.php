<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($member) ? 'Edit Family Member' : 'Add New Family Member'; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .sidebar {
            margin: 0;
            padding: 0;
            width: 200px;
            background-color: #f1f1f1;
            position: fixed;
            height: 100%;
            overflow: auto;
            transition: margin-left 0.3s;
        }
        .sidebar.hidden {
            margin-left: -200px;
        }
        .sidebar a {
            display: block;
            color: black;
            padding: 16px;
            text-decoration: none;
        }
        .sidebar a.active {
            background-color: #04AA6D;
            color: white;
        }
        .sidebar a:hover:not(.active) {
            background-color: #555;
            color: white;
        }
        div.content {
            margin-left: 200px;
            padding: 1px 16px;
            height: 1000px;
        }
        .content.hidden {
            margin-left: 0;
        }
        @media screen and (max-width: 700px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .sidebar a {
                float: left;
            }
            div.content {
                margin-left: 0;
            }
        }
        @media screen and (max-width: 400px) {
            .sidebar a {
                text-align: center;
                float: none;
            }
        }   
    </style>
</head>
<body>
<?= view('auth/sidebar'); ?>
<div class="container mt-5">
    <h2><?= isset($member) ? 'Edit ' . esc($member['name']) : 'Add New Family Member'; ?></h2>
    <form id="memberForm" action="<?= isset($member) ? base_url('auth/save/' . esc($member['name'])) : base_url('auth/addMember/' . esc($familyCode)); ?>" method="post">
        <input type="hidden" id="familyCode" name="familyCode" value="<?= isset($member) ? esc($member['familyCode']) : esc($familyCode); ?>">
        
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?= isset($member) ? esc($member['name']) : ''; ?>" required>
            <small id="nameError" class="form-text text-danger"></small>
        </div>
        
        <div class="form-group">
            <label for="gender">Gender:</label>
            <select class="form-control" id="gender" name="gender" required>
                <option value="male" <?= isset($member) && $member['gender'] === 'male' ? 'selected' : ''; ?>>Male</option>
                <option value="female" <?= isset($member) && $member['gender'] === 'female' ? 'selected' : ''; ?>>Female</option>
                <option value="other" <?= isset($member) && $member['gender'] === 'other' ? 'selected' : ''; ?>>Other</option>
            </select>
            <small id="genderError" class="form-text text-danger"></small>
        </div>

        <div class="form-group">
            <label for="dob">Date of Birth:</label>
            <input type="date" class="form-control" id="dob" name="dob" value="<?= isset($member) ? date('Y-m-d', strtotime($member['dob'])) : ''; ?>" required>
            <small id="dobError" class="form-text text-danger"></small>
        </div>

        <div class="form-group">
            <label for="relationship">Relationship:</label>
            <select class="form-control" id="relationship" name="relationship" required>
                <option value="self" <?= isset($member) && $member['relationship'] === 'self' ? 'selected' : ''; ?>>Self</option>
                <option value="spouse" <?= isset($member) && $member['relationship'] === 'spouse' ? 'selected' : ''; ?>>Spouse</option>
                <option value="child" <?= isset($member) && $member['relationship'] === 'child' ? 'selected' : ''; ?>>Child</option>
                <option value="sibling" <?= isset($member) && $member['relationship'] === 'sibling' ? 'selected' : ''; ?>>Sibling</option>
                <option value="parent" <?= isset($member) && $member['relationship'] === 'parent' ? 'selected' : ''; ?>>Parent</option>
            </select>
            <small id="relationshipError" class="form-text text-danger"></small>
        </div>

        <button type="button" class="btn btn-success" onclick="submitForm()">Save</button>
    </form>

    <div id="errorMessages" style="color: red;"></div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function() {
    $('#dob, #gender, #relationship').on('change', function() {
        validateField($(this).attr('id'));
    });
});

function validateField(fieldId) {
    $.ajax({
        url: "<?= base_url('auth/validateRulesAjax'); ?>",
        method: "POST",
        data: {
            familyCode: $('#familyCode').val(),
            dob: $('#dob').val(),
            gender: $('#gender').val(),
            relationship: $('#relationship').val(),
            field: fieldId
        },
        success: function(response) {
            $('#' + fieldId + 'Error').text('');
            if (!response.success) {
                response.errors.forEach(function(error) {
                    if (error.field === fieldId) {
                        $('#' + fieldId + 'Error').text(error.message);
                    }
                });
            }
        },
        error: function() {
            $('#errorMessages').text('An error occurred during validation.');
        }
    });
}

function submitForm() {
    let hasError = false;
    $('#errorMessages').empty();
    $('#memberForm .form-text.text-danger').each(function() {
        if ($(this).text()) {
            hasError = true;
        }
    });

    if (!hasError) {
        $('#memberForm').off('submit').submit();
    } else {
        $('#errorMessages').text('Please fix the errors before submitting.');
    }
}
</script>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger mt-3"><?= session()->getFlashdata('error'); ?></div>
<?php endif; ?>
<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success mt-3"><?= session()->getFlashdata('success'); ?></div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
