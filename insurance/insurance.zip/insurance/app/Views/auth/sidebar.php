<div class="sidebar">
    <h2>Menu</h2>
    <a href="<?= base_url('/') ?>" class="active">Home</a>
    <a href="<?= base_url('auth/dashboard2') ?>" >Dashboard</a>
    <a href="<?= base_url('auth/logout') ?>">Log Out</a>
</div>
