<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .sidebar {
            margin: 0;
            padding: 0;
            width: 200px;
            background-color: #f1f1f1;
            position: fixed;
            height: 100%;
            overflow: auto;
            transition: margin-left 0.3s; /* Smooth transition */
        }

        .sidebar.hidden {
            margin-left: -200px; /* Hide the sidebar */
        }

        /* Sidebar links */
        .sidebar a {
            display: block;
            color: black;
            padding: 16px;
            text-decoration: none;
        }

        .sidebar a.active {
            background-color: #04AA6D;
            color: white;
        }

        .sidebar a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        /* Page content */
        div.content {
            margin-left: 200px;
            padding: 1px 16px;
            height: 1000px; /* Adjust as needed */
        }

        .content.hidden {
            margin-left: 0; /* Adjust content when sidebar is hidden */
        }

        /* Responsive styles */
        @media screen and (max-width: 700px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .sidebar a {
                float: left;
            }
            div.content {
                margin-left: 0;
            }
        }

        @media screen and (max-width: 400px) {
            .sidebar a {
                text-align: center;
                float: none;
            }
        }
    </style>
</head>
<body>
<?= view('auth/sidebar'); ?> 
    <div class="content" id="content">
    <h3>Family Details</h3>
        <table class="table table-bordered" id="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>Relationship</th>
                    <th>Family Code</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($records['familyhead'])): ?>
                    <?php foreach ($records['familyhead'] as $record): ?>
                        <tr>
                            <td contentEditable="true"><?= esc($record['name']); ?></td>
                            <td contentEditable="true"><?= esc($record['gender']); ?></td>
                            <?php
                            $dob = strtotime($record['dob']);
                            $formatdob = date('d-m-Y', $dob);?>
                            <td contentEditable="true"><?= $formatdob ?></td>
                            <td contentEditable="true"><?= esc($record['relationship']); ?></td>
                            <td contentEditable="true"><?= esc($record['familyCode']); ?></td>
                            <td>
                                <?php $familyCode = $record['familyCode'];?>
                            <a href = "<?= base_url('auth/edit/'.esc($familyCode))?>">View</a>
                            </td>

                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
