<form action="<?= $isEdit ? base_url('auth/update') : base_url('auth/add') ?>" method="post">
    <!-- Name Field -->
    <input type="text" name="name" value="<?= esc($memberName); ?>" class="form-control" required>
    
    <!-- Gender Field -->
    <select name="gender" class="form-control">
        <option value="male" <?= $memberGender === 'male' ? 'selected' : '' ?>>Male</option>
        <option value="female" <?= $memberGender === 'female' ? 'selected' : '' ?>>Female</option>
        <option value="other" <?= $memberGender === 'other' ? 'selected' : '' ?>>Other</option>
    </select>
    
    <!-- Date of Birth Field -->
    <input type="date" name="dob" value="<?= esc($memberDOB); ?>" class="form-control" required>
    
    <!-- Relationship Field -->
    <select name="relationship" class="form-control">
        <option value="self" <?= $memberRelationship === 'self' ? 'selected' : '' ?>>Self</option>
        <option value="spouse" <?= $memberRelationship === 'spouse' ? 'selected' : '' ?>>Spouse</option>
        <!-- Add other options here -->
    </select>
    
    <!-- Submit Button -->
    <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Update Member' : 'Add Member' ?></button>
</form>

