<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Family Members</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .sidebar {
            margin: 0;
            padding: 0;
            width: 200px;
            background-color: #f1f1f1;
            position: fixed;
            height: 100%;
            overflow: auto;
            transition: margin-left 0.3s; /* Smooth transition */
        }

        .sidebar.hidden {
            margin-left: -200px; /* Hide the sidebar */
        }

        /* Sidebar links */
        .sidebar a {
            display: block;
            color: black;
            padding: 16px;
            text-decoration: none;
        }

        .sidebar a.active {
            background-color: #04AA6D;
            color: white;
        }

        .sidebar a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        /* Page content */
        div.content {
            margin-left: 200px;
            padding: 1px 16px;
            height: 1000px; /* Adjust as needed */
        }

        .content.hidden {
            margin-left: 0; /* Adjust content when sidebar is hidden */
        }

        /* Responsive styles */
        @media screen and (max-width: 700px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .sidebar a {
                float: left;
            }
            div.content {
                margin-left: 0;
            }
        }

        @media screen and (max-width: 400px) {
            .sidebar a {
                text-align: center;
                float: none;
            }
        }
    </style>
</head>
<body>
<?= view('auth/sidebar'); ?> 
    <div class="container mt-5">
    <h2>Edit Family Members of <?= esc($selfName); ?></h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>Relationship</th>
                    <th>Family Code</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($allMembers)): ?>
                    <?php foreach ($allMembers as $member): ?>
                        
                            <td><?= esc($member['name']); ?></td>
                            <td><?= esc($member['gender']); ?></td>
                            <?php $dob = strtotime($member['dob']);
                            $formatdob = date('d-m-Y',$dob);?>
                            <td><?= $formatdob; ?></td>
                            <td><?= esc($member['relationship']); ?></td>
                            <td><?= esc($member['familyCode']); ?></td>
                            <td>
                            <?php $code =  $member['familyCode']; $name = $member['name']?>
                                <a class = "btn btn-success"href = "<?= base_url('auth/edit2/'.esc($code).'/'.esc($name)) ?>">Edit</a>
                                <a class = "btn btn-danger"href = "<?= base_url('auth/editer/'.esc($code).'/'.esc($name)) ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td>
                        <a class = "btn btn-info"href = "<?= base_url('auth/adder/'.$code) ?>">Add New Member</a>

                        </td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No family members found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
